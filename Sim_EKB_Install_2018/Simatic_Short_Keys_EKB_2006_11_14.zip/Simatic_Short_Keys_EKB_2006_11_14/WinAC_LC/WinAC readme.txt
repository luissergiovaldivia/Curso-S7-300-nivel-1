A1WINA10.EKB SIK/SIMATIC WinAC Basis V1.x / V2.x
A1WINA30.ekb SIK/SIMATIC WinAC Basis V3.x
A1WINA40.EKB SIK/SIMATIC WinAC Basis V4.0
A1WINA41.ekb SIK/SIMATIC WinAC Basis V4.1

A1WRTX30.ekb SIK/SIMATIC WinAC RTX V3.x
A1WRTX40.ekb SIK/SIMATIC WinAC RTX V4.0
A1WRTX42.ekb SIK/SIMATIC WinAC RTX V4.2 (2005) (Renamed)

A1WIMP30.ekb SIK/SIMATIC WinAC MP V3.0 (Renamed or Cracked)
A1WIPN11.ekb SIK/SIMATIC WinAC PN V1.1 (Activated)
A1LCMP10.ekb SIK/SIMATIC WinLC/MP V1.x (Activated)

Short keys install by Siemens.exe

SISLA1WRTX0402.EKB WinAC RTX 4.2 (2005) Single FastCopy - copy this key to C:\AX NF ZZ

link to full version WinAC Basic V4.0 with SP1
http://support.automation.siemens.com/-snm-0135109872-1114240600-0000022100-0000005562-1115911445-enm-WW/llisapi.dll?func=cslib.csinfo2&siteid=cseus&lang=en&aktprim=99&content=skm%2Fmain%2Easp?SearchArea=downl%26Cookie=false%26query=*

I wait new keys for common set
plcsim@mail.ru

http://simatic.net.ru
http://plcsim.narod.ru - if you have problem with download from this page - change IP number to Russian host
